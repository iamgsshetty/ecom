# Ecommerce-webapp
consists of an ecommerce website with a builtin Fraud detection model
